#include <stdio.h>

#define NUM_PAGES 4
#define PAGE_SIZE 4
#define FRAME_SIZE 4

// Simulating the Page Table
int pageTable[NUM_PAGES] = {1, 3, 0, 2}; // Maps logical page numbers to physical frame numbers

// Function to convert logical address to physical address
void logicalToPhysical(int logicalAddress) {
    // Calculate page number and page offset
    int pageNumber = logicalAddress / PAGE_SIZE;
    int pageOffset = logicalAddress % PAGE_SIZE;

    // Check if page number is valid
    if (pageNumber >= NUM_PAGES) {
        printf("Invalid page number!\n");
        return;
    }

    // Get the physical frame number from the page table
    int physicalFrame = pageTable[pageNumber];

    // Calculate physical address
    int physicalAddress = (physicalFrame * FRAME_SIZE) + pageOffset;

    printf("Logical Address: %d\n", logicalAddress);
    printf("Page Number: %d, Page Offset: %d\n", pageNumber, pageOffset);
    printf("Physical Frame: %d\n", physicalFrame);
    printf("Physical Address: %d\n", physicalAddress);
}

int main() {
    int logicalAddress;

    // Get the logical address from the user
    printf("Enter a logical address: ");
    scanf("%d", &logicalAddress);

    logicalToPhysical(logicalAddress);

    return 0;
}
