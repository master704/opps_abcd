#include <stdio.h>
#include <limits.h>

#define MAX_FRAMES 3

void FIFO(int pages[], int num_pages) {
    int frames[MAX_FRAMES];
    int pageFaults = 0, pageIndex = 0;

    // Initialize frames to -1 (indicating empty)
    for (int i = 0; i < MAX_FRAMES; i++) {
        frames[i] = -1;
    }

    for (int i = 0; i < num_pages; i++) {
        int page = pages[i];
        int found = 0;

        // Check if the page is already in one of the frames
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] == page) {
                found = 1;
                break;
            }
        }

        // If page is not found in frames, replace the first page (FIFO)
        if (!found) {
            frames[pageIndex] = page;
            pageIndex = (pageIndex + 1) % MAX_FRAMES;
            pageFaults++;
        }

        // Display the current frames
        printf("Pages in memory: ");
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] != -1) {
                printf("%d ", frames[j]);
            }
        }
        printf("\n");
    }

    printf("\nTotal page faults: %d\n", pageFaults);
}

void Optimal(int pages[], int num_pages) {
    int frames[MAX_FRAMES];
    int pageFaults = 0;

    // Initialize frames to -1 (indicating empty)
    for (int i = 0; i < MAX_FRAMES; i++) {
        frames[i] = -1;
    }

    for (int i = 0; i < num_pages; i++) {
        int page = pages[i];
        int found = 0;

        // Check if the page is already in one of the frames
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] == page) {
                found = 1;
                break;
            }
        }

        // If page is not found in frames, replace the page using Optimal algorithm
        if (!found) {
            int farthest = -1, replaceIndex = -1;
            for (int j = 0; j < MAX_FRAMES; j++) {
                int k;
                // Find the page that will not be used for the longest time in the future
                for (k = i + 1; k < num_pages; k++) {
                    if (pages[k] == frames[j]) {
                        break;
                    }
                }
                if (k == num_pages) {
                    replaceIndex = j;
                    break;
                }
                if (k > farthest) {
                    farthest = k;
                    replaceIndex = j;
                }
            }
            frames[replaceIndex] = page;
            pageFaults++;
        }

        // Display the current frames
        printf("Pages in memory: ");
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] != -1) {
                printf("%d ", frames[j]);
            }
        }
        printf("\n");
    }

    printf("\nTotal page faults: %d\n", pageFaults);
}

void MRU(int pages[], int num_pages) {
    int frames[MAX_FRAMES];
    int pageFaults = 0;

    // Initialize frames to -1 (indicating empty)
    for (int i = 0; i < MAX_FRAMES; i++) {
        frames[i] = -1;
    }

    for (int i = 0; i < num_pages; i++) {
        int page = pages[i];
        int found = 0;

        // Check if the page is already in one of the frames
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] == page) {
                found = 1;
                break;
            }
        }

        // If page is not found in frames, replace the most recently used page (MRU)
        if (!found) {
            int mruIndex = -1;
            int latest = -1;
            for (int j = 0; j < MAX_FRAMES; j++) {
                if (frames[j] == -1) {
                    mruIndex = j;
                    break;
                }
            }

            if (mruIndex == -1) {
                mruIndex = 0;
                for (int j = 1; j < MAX_FRAMES; j++) {
                    if (frames[j] != -1) {
                        mruIndex = j;
                        break;
                    }
                }
            }

            frames[mruIndex] = page;
            pageFaults++;
        }

        // Display the current frames
        printf("Pages in memory: ");
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] != -1) {
                printf("%d ", frames[j]);
            }
        }
        printf("\n");
    }

    printf("\nTotal page faults: %d\n", pageFaults);
}

void LRU(int pages[], int num_pages) {
    int frames[MAX_FRAMES];
    int pageFaults = 0, time[MAX_FRAMES] = {0};  // Track the time when pages are last used

    // Initialize frames to -1 (indicating empty)
    for (int i = 0; i < MAX_FRAMES; i++) {
        frames[i] = -1;
    }

    for (int i = 0; i < num_pages; i++) {
        int page = pages[i];
        int found = 0;

        // Check if the page is already in one of the frames
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] == page) {
                found = 1;
                time[j] = i;  // Update last used time
                break;
            }
        }

        // If page is not found in frames, replace the least recently used page (LRU)
        if (!found) {
            int lruIndex = 0;
            for (int j = 1; j < MAX_FRAMES; j++) {
                if (time[j] < time[lruIndex]) {
                    lruIndex = j;
                }
            }
            frames[lruIndex] = page;
            time[lruIndex] = i;
            pageFaults++;
        }

        // Display the current frames
        printf("Pages in memory: ");
        for (int j = 0; j < MAX_FRAMES; j++) {
            if (frames[j] != -1) {
                printf("%d ", frames[j]);
            }
        }
        printf("\n");
    }

    printf("\nTotal page faults: %d\n", pageFaults);
}

int main() {
    int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0};
    int num_pages = sizeof(pages) / sizeof(pages[0]);
    int choice;

    printf("Choose the page replacement algorithm:\n");
    printf("1. FIFO\n");
    printf("2. Optimal\n");
    printf("3. MRU\n");
    printf("4. LRU\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            FIFO(pages, num_pages);
            break;
        case 2:
            Optimal(pages, num_pages);
            break;
        case 3:
            MRU(pages, num_pages);
            break;
        case 4:
            LRU(pages, num_pages);
            break;
        default:
            printf("Invalid choice!\n");
            break;
    }

    return 0;
}
