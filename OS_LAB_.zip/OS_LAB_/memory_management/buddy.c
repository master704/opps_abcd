#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 10

typedef struct Block {
    int size;
    int allocated;
} Block;

Block memory[MAX_BLOCKS];

void initializeMemory(int totalMemorySize, int blockSize) {
    int numBlocks = totalMemorySize / blockSize;
    for (int i = 0; i < numBlocks; i++) {
        memory[i].size = blockSize;
        memory[i].allocated = 0;
    }
}

int findFreeBlock(int size) {
    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (memory[i].allocated == 0 && memory[i].size >= size) {
            return i;
        }
    }
    return -1;
}

void allocateMemory(int size) {
    int blockIndex = findFreeBlock(size);
    if (blockIndex == -1) {
        printf("Memory allocation failed! Not enough space.\n");
        return;
    }
    memory[blockIndex].allocated = 1;
    printf("Allocated %d units of memory in block %d of size %d units.\n", size, blockIndex, memory[blockIndex].size);
}

void deallocateMemory(int blockIndex) {
    if (blockIndex < 0 || blockIndex >= MAX_BLOCKS || memory[blockIndex].allocated == 0) {
        printf("Invalid or unallocated block!\n");
        return;
    }
    memory[blockIndex].allocated = 0;
    printf("Deallocated memory from block %d.\n", blockIndex);
}

void displayMemory(int totalMemorySize) {
    printf("\nMemory Status:\n");
    for (int i = 0; i < totalMemorySize / 2; i++) {
        printf("Block %d: Size = %d, Allocated = %s\n", i, memory[i].size, memory[i].allocated ? "Yes" : "No");
    }
}

int main() {
    int totalMemorySize, blockSize, choice, size;

    printf("Enter the total memory size: ");
    scanf("%d", &totalMemorySize);
    printf("Enter the block size: ");
    scanf("%d", &blockSize);

    initializeMemory(totalMemorySize, blockSize);

    do {
        printf("\nMenu:\n");
        printf("1. Allocate memory\n");
        printf("2. Deallocate memory\n");
        printf("3. Display memory status\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the size of memory to allocate: ");
                scanf("%d", &size);
                allocateMemory(size);
                break;
            case 2:
                printf("Enter the block index to deallocate: ");
                scanf("%d", &size);
                deallocateMemory(size);
                break;
            case 3:
                displayMemory(totalMemorySize);
                break;
            case 4:
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 4);

    return 0;
}
