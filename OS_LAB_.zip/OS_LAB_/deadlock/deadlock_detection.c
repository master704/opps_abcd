#include <stdio.h>

#define MAX_PROCESSES 10
#define MAX_RESOURCES 5

int main() {
    int n, m, i, j;
    int allocation[MAX_PROCESSES][MAX_RESOURCES];
    int request[MAX_PROCESSES][MAX_RESOURCES];
    int available[MAX_RESOURCES];
    int work[MAX_RESOURCES];
    int finish[MAX_PROCESSES] = {0};
    int safeSequence[MAX_PROCESSES], seqIndex = 0;
    int deadlocked[MAX_PROCESSES], deadlockCount = 0;

    // Input the number of processes and resources
    printf("Enter the number of processes: ");
    scanf("%d", &n);
    printf("Enter the number of resources: ");
    scanf("%d", &m);

    // Input Allocation matrix
    printf("Enter the Allocation matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &allocation[i][j]);
        }
    }

    // Input Request matrix
    printf("Enter the Request matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &request[i][j]);
        }
    }

    // Input Available vector
    printf("Enter the Available vector:\n");
    for (j = 0; j < m; j++) {
        scanf("%d", &available[j]);
        work[j] = available[j]; // Initialize Work with Available
    }

    // Process resource allocation
    while (1) {
        int processAllocated = 0;

        for (i = 0; i < n; i++) {
            if (!finish[i]) { // If process is not finished
                int canAllocate = 1;

                // Check if request can be satisfied
                for (j = 0; j < m; j++) {
                    if (request[i][j] > work[j]) {
                        canAllocate = 0;
                        break;
                    }
                }

                // If resources can be allocated
                if (canAllocate) {
                    for (j = 0; j < m; j++) {
                        work[j] += allocation[i][j];
                    }
                    finish[i] = 1; // Mark process as finished
                    safeSequence[seqIndex++] = i;
                    processAllocated = 1;
                }
            }
        }

        if (!processAllocated) {
            break; // No process could be allocated in this pass
        }
    }

   
    for (i = 0; i < n; i++) {
        if (!finish[i]) {
            deadlocked[deadlockCount++] = i; 
        }
    }

  
    if (deadlockCount == 0) {
        printf("No deadlock detected.\nSafe sequence: ");
        for (i = 0; i < seqIndex; i++) {
            printf("P%d ", safeSequence[i]);
        }
        printf("\n");
    } else {
        printf("Deadlock detected in processes: ");
        for (i = 0; i < deadlockCount; i++) {
            printf("P%d ", deadlocked[i]);
        }
        printf("\n");
    }

    return 0;
}
