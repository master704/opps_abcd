#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

void calculateFCFS(int requests[], int num_requests, int initial_position) {
    int total_distance = 0;
    int current_position = initial_position;

    printf("\n--- FCFS (First-Come-First-Serve) ---\n");
    printf("Processing Steps:\n");

    for (int i = 0; i < num_requests; i++) {
        int distance = abs(current_position - requests[i]);
        total_distance += distance;
        printf("Move to %d: Distance from %d to %d = %d\n", requests[i], current_position, requests[i], distance);
        current_position = requests[i];
    }

    printf("\nTotal Distance: %d\n", total_distance);
    printf("Average Seek Time: %.2f\n", (float)total_distance / num_requests);
}

void calculateSSTF(int requests[], int num_requests, int initial_position) {
    int total_distance = 0;
    int current_position = initial_position;
    bool serviced[num_requests];

    for (int i = 0; i < num_requests; i++) {
        serviced[i] = false;
    }

    printf("\n--- SSTF (Shortest Seek Time First) ---\n");
    printf("Order of servicing requests:\n");

    for (int i = 0; i < num_requests; i++) {
        int closest_idx = -1;
        int closest_distance = 1e9;

        for (int j = 0; j < num_requests; j++) {
            if (!serviced[j]) {
                int distance = abs(current_position - requests[j]);
                if (distance < closest_distance) {
                    closest_distance = distance;
                    closest_idx = j;
                }
            }
        }

        if (closest_idx != -1) {
            printf("Move from %d to %d (Distance = %d)\n",
                   current_position, requests[closest_idx], closest_distance);
            total_distance += closest_distance;
            current_position = requests[closest_idx];
            serviced[closest_idx] = true;
        }
    }

    printf("\nTotal Distance (Seek Time): %d\n", total_distance);
    printf("Average Seek Time: %.2f\n", (float)total_distance / num_requests);
}

void calculateSCAN(int requests[], int num_requests, int head) {
    int total_movement = 0;
    int queue[num_requests + 1], temp, dloc;

    // Add head position to queue
    for (int i = 0; i < num_requests; i++) {
        queue[i] = requests[i];
    }
    queue[num_requests] = head;
    num_requests++;

    // Sort the queue
    for (int i = 0; i < num_requests - 1; i++) {
        for (int j = i + 1; j < num_requests; j++) {
            if (queue[i] > queue[j]) {
                temp = queue[i];
                queue[i] = queue[j];
                queue[j] = temp;
            }
        }
    }

    // Find the location of the head in the queue
    for (int i = 0; i < num_requests; i++) {
        if (queue[i] == head) {
            dloc = i;
            break;
        }
    }

    printf("\n--- SCAN (Elevator Algorithm) ---\n");
    printf("Disk servicing order:\n");

    for (int i = dloc; i < num_requests; i++) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    for (int i = dloc - 1; i >= 0; i--) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    printf("\nTotal movement of cylinders: %d\n", total_movement);
}

void calculateCSCAN(int requests[], int num_requests, int head, int max_cylinder) {
    int total_movement = 0;
    int queue[num_requests + 2], temp, dloc;

    // Add head and maximum cylinder to the queue
    for (int i = 0; i < num_requests; i++) {
        queue[i] = requests[i];
    }
    queue[num_requests] = head;
    queue[num_requests + 1] = max_cylinder;
    num_requests += 2;

    // Sort the queue
    for (int i = 0; i < num_requests - 1; i++) {
        for (int j = i + 1; j < num_requests; j++) {
            if (queue[i] > queue[j]) {
                temp = queue[i];
                queue[i] = queue[j];
                queue[j] = temp;
            }
        }
    }

    // Find the location of the head in the queue
    for (int i = 0; i < num_requests; i++) {
        if (queue[i] == head) {
            dloc = i;
            break;
        }
    }

    printf("\n--- C-SCAN (Circular SCAN) ---\n");
    printf("Disk servicing order:\n");

    for (int i = dloc; i < num_requests; i++) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    head = 0;
    total_movement += abs(queue[num_requests - 1] - head);
    printf("%d ", head);

    for (int i = 0; i < dloc; i++) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    printf("\nTotal movement of cylinders: %d\n", total_movement);
}

int main() {
    int choice, initial_position, num_requests, max_cylinder;
    printf("Enter the initial position of the disk head: ");
    scanf("%d", &initial_position);

    printf("Enter the number of disk requests: ");
    scanf("%d", &num_requests);

    int requests[num_requests];
    printf("Enter the disk requests:\n");
    for (int i = 0; i < num_requests; i++) {
        printf("Request %d: ", i + 1);
        scanf("%d", &requests[i]);
    }

    printf("Enter the maximum cylinder value: ");
    scanf("%d", &max_cylinder);

    do {
        printf("\n--- Disk Scheduling Algorithms ---\n");
        printf("1. FCFS\n2. SSTF\n3. SCAN\n4. C-SCAN\n5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                calculateFCFS(requests, num_requests, initial_position);
                break;
            case 2:
                calculateSSTF(requests, num_requests, initial_position);
                break;
            case 3:
                calculateSCAN(requests, num_requests, initial_position);
                break;
            case 4:
                calculateCSCAN(requests, num_requests, initial_position, max_cylinder);
                break;
            case 5:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 5);

    return 0;
}
