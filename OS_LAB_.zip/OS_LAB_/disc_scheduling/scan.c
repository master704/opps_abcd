#include <stdio.h>
#include <stdlib.h>

int main() {
    int queue[20], q_size, head, temp, total_movement = 0;
    int dloc;

    printf("Input number of disk locations: ");
    scanf("%d", &q_size);

    printf("Enter head position: ");
    scanf("%d", &head);

    printf("Input elements into disk queue:\n");
    for (int i = 0; i < q_size; i++) {
        scanf("%d", &queue[i]);
    }

    for (int i = 0; i < q_size - 1; i++) {
        for (int j = i + 1; j < q_size; j++) {
            if (queue[i] > queue[j]) {
                temp = queue[i];
                queue[i] = queue[j];
                queue[j] = temp;
            }
        }
    }

    for (int i = 0; i < q_size; i++) {
        if (queue[i] >= head) {
            dloc = i;
            break;
        }
    }

    printf("\nDisk servicing order:\n");

    for (int i = dloc; i < q_size; i++) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    for (int i = dloc - 1; i >= 0; i--) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    printf("\nTotal movement of cylinders: %d\n", total_movement);

    return 0;
}
