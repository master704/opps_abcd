#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void calculateSSTF(int requests[], int num_requests, int initial_position) {
    int total_distance = 0;
    int current_position = initial_position;
    bool serviced[num_requests];

    for (int i = 0; i < num_requests; i++) {
        serviced[i] = false;
    }

    printf("\nOrder of servicing requests:\n");

    for (int i = 0; i < num_requests; i++) {
        int closest_idx = -1;
        int closest_distance = 1e9;

        for (int j = 0; j < num_requests; j++) {
            if (!serviced[j]) {
                int distance = abs(current_position - requests[j]);
                if (distance < closest_distance) {
                    closest_distance = distance;
                    closest_idx = j;
                }
            }
        }

        if (closest_idx != -1) {
            printf("Move from %d to %d (Distance = %d)\n",
                   current_position, requests[closest_idx], closest_distance);
            total_distance += closest_distance;
            current_position = requests[closest_idx];
            serviced[closest_idx] = true;
        }
    }

    printf("\nTotal Distance (Seek Time): %d\n", total_distance);
    printf("Average Seek Time: %.2f\n", (float)total_distance / num_requests);
}

int main() {
    int initial_position;
    int num_requests;

    printf("Enter the initial position of the disk head: ");
    scanf("%d", &initial_position);

    printf("Enter the number of disk requests: ");
    scanf("%d", &num_requests);

    int requests[num_requests];
    printf("Enter the disk requests:\n");
    for (int i = 0; i < num_requests; i++) {
        printf("Request %d: ", i + 1);
        scanf("%d", &requests[i]);
    }

    calculateSSTF(requests, num_requests, initial_position);

    return 0;
}
