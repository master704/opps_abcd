#include <stdio.h>
#include <stdlib.h>

void calculateFCFS(int requests[], int num_requests, int initial_position) {
    int total_distance = 0;
    int current_position = initial_position;

    printf("Processing Steps:\n");

    for (int i = 0; i < num_requests; i++) {
        int distance = abs(current_position - requests[i]);
        total_distance += distance;
        printf("Move to %d: Distance from %d to %d = %d\n", requests[i], current_position, requests[i], distance);
        current_position = requests[i];
    }

    printf("\nTotal Distance: %d\n", total_distance);
    printf("Average Seek Time: %.2f\n", (float)total_distance / num_requests);
}

int main() {
    int initial_position;
    int num_requests;

    printf("Enter the initial position of the disk head: ");
    scanf("%d", &initial_position);

    printf("Enter the number of disk requests: ");
    scanf("%d", &num_requests);

    int requests[num_requests];
    printf("Enter the disk requests:\n");
    for (int i = 0; i < num_requests; i++) {
        printf("Request %d: ", i + 1);
        scanf("%d", &requests[i]);
    }

    calculateFCFS(requests, num_requests, initial_position);

    return 0;
}
