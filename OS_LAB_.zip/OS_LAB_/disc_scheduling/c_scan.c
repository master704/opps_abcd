#include <stdio.h>
#include <stdlib.h>

int main() {
    int queue[20], q_size, head, temp, total_movement = 0;
    int max_cylinder;

    printf("Input number of disk locations: ");
    scanf("%d", &q_size);

    printf("Enter head position: ");
    scanf("%d", &head);

    printf("Enter the maximum cylinder value: ");
    scanf("%d", &max_cylinder);

    printf("Input elements into disk queue:\n");
    for (int i = 0; i < q_size; i++) {
        scanf("%d", &queue[i]);
    }

    queue[q_size] = head;
    queue[q_size + 1] = max_cylinder;
    q_size += 2;

    for (int i = 0; i < q_size - 1; i++) {
        for (int j = i + 1; j < q_size; j++) {
            if (queue[i] > queue[j]) {
                temp = queue[i];
                queue[i] = queue[j];
                queue[j] = temp;
            }
        }
    }

    int dloc = 0;
    for (int i = 0; i < q_size; i++) {
        if (queue[i] == head) {
            dloc = i;
            break;
        }
    }

    printf("\nDisk servicing order:\n");

    for (int i = dloc; i < q_size; i++) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    head = 0;
    total_movement += abs(queue[q_size - 1] - head);
    printf("%d ", head);

    for (int i = 0; i < dloc; i++) {
        printf("%d ", queue[i]);
        total_movement += abs(head - queue[i]);
        head = queue[i];
    }

    printf("\nTotal movement of cylinders: %d\n", total_movement);

    return 0;
}
