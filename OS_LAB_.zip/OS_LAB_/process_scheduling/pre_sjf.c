#include <stdio.h>

int main() {
    int n, arrival_time[10], burst_time[10], remaining_time[10], completion_time[10];
    int waiting_time[10], turnaround_time[10], process[10];
    int total_waiting_time = 0, total_turnaround_time = 0;
    int completed = 0, time = 0, min_time = 1e9, shortest = -1, finish_time;
    int found = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    printf("Enter Arrival Time and Burst Time for each process:\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d Arrival Time: ", i + 1);
        scanf("%d", &arrival_time[i]);
        printf("Process %d Burst Time: ", i + 1);
        scanf("%d", &burst_time[i]);
        remaining_time[i] = burst_time[i];
    }

    while (completed < n) {
        for (int i = 0; i < n; i++) {
            if (arrival_time[i] <= time && remaining_time[i] > 0 && remaining_time[i] < min_time) {
                min_time = remaining_time[i];
                shortest = i;
                found = 1;
            }
        }

        if (!found) {
            time++;
            continue;
        }

        remaining_time[shortest]--;
        min_time = remaining_time[shortest] == 0 ? 1e9 : remaining_time[shortest];

        if (remaining_time[shortest] == 0) {
            completed++;
            finish_time = time + 1;
            completion_time[shortest] = finish_time;
            waiting_time[shortest] = finish_time - arrival_time[shortest] - burst_time[shortest];
            if (waiting_time[shortest] < 0)
                waiting_time[shortest] = 0;
        }

        time++;
        found = 0;
    }

    for (int i = 0; i < n; i++) {
        turnaround_time[i] = burst_time[i] + waiting_time[i];
        total_waiting_time += waiting_time[i];
        total_turnaround_time += turnaround_time[i];
    }

    printf("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t\t%d\t\t%d\t\t%d\t\t%d\n", i + 1, arrival_time[i], burst_time[i], waiting_time[i], turnaround_time[i]);
    }

    printf("\nAverage Waiting Time: %.2f\n", (float)total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n", (float)total_turnaround_time / n);

    return 0;
}
