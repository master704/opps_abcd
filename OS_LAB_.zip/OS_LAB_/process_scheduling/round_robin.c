#include <stdio.h>

int main() {
    int n, quantum, arrival_time[10], burst_time[10], remaining_time[10];
    int waiting_time[10] = {0}, turnaround_time[10] = {0};
    int total_waiting_time = 0, total_turnaround_time = 0, time = 0, completed = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    printf("Enter Arrival Time and Burst Time for each process:\n");
    for (int i = 0; i < n; i++) {
        printf("Process %d Arrival Time: ", i + 1);
        scanf("%d", &arrival_time[i]);
        printf("Process %d Burst Time: ", i + 1);
        scanf("%d", &burst_time[i]);
        remaining_time[i] = burst_time[i];
    }

    printf("Enter the time quantum: ");
    scanf("%d", &quantum);

    while (completed < n) {
        int idle = 1;
        for (int i = 0; i < n; i++) {
            if (remaining_time[i] > 0 && arrival_time[i] <= time) {
                idle = 0;
                if (remaining_time[i] > quantum) {
                    time += quantum;
                    remaining_time[i] -= quantum;
                } else {
                    time += remaining_time[i];
                    waiting_time[i] = time - arrival_time[i] - burst_time[i];
                    turnaround_time[i] = waiting_time[i] + burst_time[i];
                    remaining_time[i] = 0;
                    completed++;
                }
            }
        }
        if (idle) time++; // Increment time if all processes are idle
    }

    for (int i = 0; i < n; i++) {
        total_waiting_time += waiting_time[i];
        total_turnaround_time += turnaround_time[i];
    }

    printf("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t\t%d\t\t%d\t\t%d\t\t%d\n", i + 1, arrival_time[i], burst_time[i], waiting_time[i], turnaround_time[i]);
    }

    printf("\nAverage Waiting Time: %.2f\n", (float)total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n", (float)total_turnaround_time / n);

    return 0;
}
